---
name: claude-skill-docx-batch
description: |
  高效的 Word 文档批量编辑工具，基于 python-docx 封装。适用于：(1) 批量格式化（字体、对齐、缩进、行距）(2) 段落/表格/图片的增删改 (3) 全局文本替换 (4) 清理自动编号。
  触发场景：需要快速统一文档格式、批量修改样式、处理大量 Word 文档时使用。
user-invocable: true
license: MIT
metadata:
  version: "1.1.0"
  author: mykcs
  category: document-processing
  triggers:
    - 批量编辑 Word
    - docx 批量
    - 文档格式化
    - word 批量处理
    - 批量修改样式
    - 批量清理空段落
  tags:
    - docx
    - word
    - batch
    - document
    - python-docx
version: "1.1.0"
author: "mykcs"
last_updated: "2026-07-19"
---

# DocxEditor - Word 文档批量编辑工具

使用此 skill 前，确保已安装依赖：`pip install python-docx`

## 核心概念

### 三轨制索引

文档由三个独立列表组成，索引互不干扰：

| 轨道 | 索引参数 | 说明 |
|------|----------|------|
| 段落 | `index` | 包含标题和正文 |
| 表格 | `table_index` | 独立于段落 |
| 图片 | `image_index` | 独立于段落 |

**关键**：段落删除后，后面的段落 index 会自动前移。但 `batch_update` 会**倒序执行**所有操作，所以相同 index 的删除操作不会相互干扰。

### 工作流程

```
查询 → 构建操作列表 → 执行（倒序） → 保存
```

1. **查询** → 获取最新索引和内容
2. **构建操作列表** → 组装 `batch_update` 参数
3. **执行** → `batch_update` 自动倒序执行，无需手动计算索引漂移
4. **保存** → `save()` 写入文件

## 快速开始

```python
import sys
sys.path.insert(0, 'SKILL_DIR/scripts')  # 替换为实际路径
from docx_editor import DocxEditor

editor = DocxEditor('input.docx')
outline = editor.get_outline()
print(f"共 {outline['total']} 段落")

editor.batch_update([
    {'op': 'update_style', 'index': 0, 'font': {'name': '宋体'}, 'alignment': 'left'},
])
editor.save('output.docx')
```

## 查询接口

| 方法 | 用途 |
|------|------|
| `get_outline()` | 获取文档大纲（标题层级和索引） |
| `read_content(indices)` | 读取指定段落详情 |
| `get_tables_outline()` | 获取表格概览 |
| `read_table(table_index)` | 读取表格内容 |
| `get_images_outline()` | 获取图片概览 |

## 修改操作

所有修改通过 `batch_update(operations)` 执行，常用操作：

### 段落操作

```python
# 删除（自动保护含图片的段落）
{'op': 'delete', 'index': 50}

# 强制删除（忽略图片保护）
{'op': 'delete', 'index': 50, 'force': True}

# 插入新段落
{'op': 'insert', 'index': 10, 'position': 'after', 'text': '新内容'}

# 更新样式（最常用）
{'op': 'update_style', 'index': 20,
 'font': {'name': '宋体', 'size': 12, 'bold': False},
 'alignment': 'left',      # left/center/right/justify
 'indent': {'first_line': 0.74, 'left': 0},   # 厘米
 'spacing': {'before': 0, 'after': 0, 'line': 1.5}}  # line 是倍数

# 正则替换（当前段落）
{'op': 'replace_text', 'index': 30, 'pattern': r'^（\d）\s*', 'replacement': '', 'regex': True}

# 全局替换（所有段落）
{'op': 'replace_text_global', 'pattern': '旧文本', 'replacement': '新文本'}

# 清理自动编号（修复 Word 编号错乱）
{'op': 'clean_xml', 'index': 15, 'remove': ['numPr']}

# 重写段落内容
{'op': 'set_text', 'index': 25, 'text': '新的段落内容'}
```

### 表格操作

```python
# 更新单个单元格
{'op': 'update_table_cell', 'table_index': 0, 'row': 1, 'col': 2, 'text': '新内容'}

# 更新整行
{'op': 'update_table_row', 'table_index': 0, 'row': 1, 'texts': ['列1', '列2', '列3']}

# 更新整列
{'op': 'update_table_col', 'table_index': 0, 'col': 1, 'texts': ['行1', '行2', '行3']}
```

### 图片操作

```python
# 删除图片
{'op': 'delete_image', 'image_index': 0}

# 调整图片宽度（高度自动按比例）
{'op': 'resize_image', 'image_index': 0, 'width': 10.0}  # 厘米

# 插入图片
{'op': 'insert_image', 'index': 10, 'path': '/path/to/img.png', 'width': 6.0}
```

### 系统操作

```python
# 让 Word 打开时刷新目录/页码
{'op': 'update_fields_on_open'}
```

## 常用工作流示例

### 工作流 1：统一文档格式

```python
editor = DocxEditor('input.docx')

# 全文统一字体和行距
editor.batch_update([
    {'op': 'update_style', 'index': i,
     'font': {'name': '宋体', 'size': 12},
     'spacing': {'before': 0, 'after': 6, 'line': 1.5}}
    for i in range(editor.get_outline()['total'])
])
editor.save('formatted.docx')
```

### 工作流 2：清理空段落

```python
editor = DocxEditor('input.docx')
content = editor.read_content(range(editor.get_outline()['total']))

# 筛选出真正为空的段落
ops = [
    {'op': 'delete', 'index': p['index']}
    for p in content
    if p['is_truly_empty']
]

if ops:
    editor.batch_update(ops)
    editor.save('cleaned.docx')
    print(f"删除了 {len(ops)} 个空段落")
else:
    print("没有空段落需要清理")
```

### 工作流 3：批量替换文本 + 修复编号

```python
editor = DocxEditor('input.docx')

editor.batch_update([
    # 全局替换
    {'op': 'replace_text_global', 'pattern': '旧公司名', 'replacement': '新公司名'},
    # 清理编号错乱
    {'op': 'clean_xml', 'index': i, 'remove': ['numPr']}
    for i in range(editor.get_outline()['total'])
])

editor.save('replaced.docx')
```

### 工作流 4：处理表格数据

```python
editor = DocxEditor('report.docx')

# 读取表格内容
tables = editor.get_tables_outline()
for t in tables:
    print(f"表格 {t['index']}: {t['rows']}行 x {t['cols']}列")

# 批量更新表格中的数据
editor.batch_update([
    {'op': 'update_table_cell', 'table_index': 0, 'row': r, 'col': c,
     'text': f'R{r}C{c}'}
    for r in range(1, 4)
    for c in range(3)
])
editor.save('table_updated.docx')
```

## 重要：删除操作的安全保护

Word 段落可能包含隐藏内容（图片、OLE对象），`text` 属性为空但实际有内容。

`read_content` 返回的关键字段：

| 字段 | 含义 |
|------|------|
| `is_empty` | 文本为空（可能包含图片） |
| `is_truly_empty` | 真正为空，可安全删除 |
| `has_embedded` | 是否包含图片/OLE等 |

**安全删除逻辑**：
```python
content = editor.read_content(range(100))
safe_ops = [
    {'op': 'delete', 'index': p['index']}
    for p in content
    if p['is_truly_empty']  # 只删除真正为空的
]
editor.batch_update(safe_ops)
```

## 反模式（Anti-Patterns）

以下操作**禁止**执行：

- ❌ **直接删除 index=0**：通常是文档标题或空模板，直接删除会破坏文档结构
- ❌ **不检查 `is_truly_empty` 就删除** `is_empty=True` 的段落：可能删除含有图片/OLE 的段落
- ❌ **批量删除后立即插入同一 index**：倒序执行保证顺序，但同 index 的删除+插入行为取决于操作顺序
- ❌ **处理大文档（100+ 段落）时不用 batch_update**：逐个操作会极慢，batch_update 一次完成所有修改
- ❌ **不保存就关闭**：Word 文档必须调用 `save()` 才能写入磁盘

## 限制

- 不支持 tracked changes（需要请用官方 docx skill）
- 不支持读取图片内容，只能操作尺寸或删除
- 目录/页码需用 `update_fields_on_open`，让 Word 自己计算
- 表格合并/拆分单元格不支持
